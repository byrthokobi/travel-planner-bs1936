'use client'

import React, { useState } from 'react'
import { signIn, useSession } from "next-auth/react";
import { redirect, useRouter } from 'next/navigation';
import { GithubSignIn } from '@/components/github-sign-in';
import { auth } from '@/lib/auth';

const loginPage = () => {

    // const session = await auth();
    // if (session) redirect("/");

    // const { data: session } = useSession();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const router = useRouter();

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        const res = await signIn("credentials", {
            redirect: false,
            email,
            password,
        });

        if (res?.error) {
            setError(res.error); // display error
        } else if (res?.ok) {
            // Redirect to home page
            router.push("/");
        }
    };


    return (
        <div className="max-w-md mx-auto">
            <h1 className="text-xl font-semibold">Login</h1>
            {error && <div className="text-red-500">{error}</div>}
            <GithubSignIn />
            <form className="mt-4" onSubmit={handleLogin}>
                <input
                    type="email"
                    placeholder="Email"
                    className="w-full mb-2 p-2 border border-gray-300"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
                <input
                    type="password"
                    placeholder="Password"
                    className="w-full mb-2 p-2 border border-gray-300"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                <button type="submit" className="w-full bg-blue-500 text-white py-2 mt-2">
                    Login
                </button>
            </form>
        </div>
    )
}

export default loginPage;
