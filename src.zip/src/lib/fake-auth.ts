export const demoUser = {
    username: "admin",
    password: "123456"
}